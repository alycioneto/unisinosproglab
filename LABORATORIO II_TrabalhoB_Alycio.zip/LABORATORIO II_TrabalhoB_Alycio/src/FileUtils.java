
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unisinos
 */
public class FileUtils {
    public static void LeArquivo(String fileName) {
        int quantLinhas = 0;		
        try {
            BufferedReader in = new BufferedReader(new FileReader(fileName));
            String line = in.readLine();
            while (line != null) {
                quantLinhas++;
                line = in.readLine();
            } 
            in.close();
        } catch (FileNotFoundException e) {
            System.out.println("Arquivo \""+fileName+"\" não existe.");
        } catch (IOException e) {
            System.out.println("Erro na leitura de " + fileName+".");
        }
    }
    
    public void escreveArquivo(String fileName, String text){
        try{
            FileWriter fr = new FileWriter(new File(fileName));
            PrintWriter out = new PrintWriter(fr);
            out.println(text);
            out.close();
        } catch (IOException e){
            System.out.println("Erro ao escrever o arquivo.");
	}
    }
        
}
