/**
 *
 * @author Unisinos
 */
public class DoublyLinkedList<E> implements List<E> {
    	DNode<E> head;
	DNode<E> tail;
	int numElements;
        
        public DoublyLinkedList() {
            head = tail = null; 
            numElements = 0;
        }
        public int numElements() {
            return numElements;
	}

	/* (non-Javadoc)
	 * @see br.unisinos.prog2lab2.List#isEmpty()
	 */
	public boolean isEmpty() {
		return numElements == 0;
	}
        public boolean isFull() {
            return false;
	}
        
        public void insertFirst(E element) {
		// cria um novo n� e o torna o novo "head"
            DNode<E> newNode = new DNode<>(element);
            if (isEmpty())
                head = tail = newNode;
            else {
                newNode.setNext(head);
                head.setPrevious(newNode);
                head = newNode;
            }
            numElements++;
	}
        
	public void insertLast(E element) {
		// cria um novo n� e o torna o novo "tail"
            DNode<E> newNode = new DNode<>(element);
            if (isEmpty())
                head = tail = newNode;
            else {
                newNode.setPrevious(tail);
                tail.setNext(newNode);
                tail = newNode;
            }
            numElements++;
	}
	public void insert(E element, int pos) {
		if (pos < 0  ||  pos > numElements)
                    throw new IndexOutOfBoundsException();
		if (pos == 0)
                    insertFirst(element);
		else if (pos == numElements) 
                    insertLast(element);
		else {
                    DNode<E> prev = head;
                    for (int i = 0; i < pos-1; i++)
                        prev = prev.getNext();
                    DNode<E> newNode = new DNode<>(element);
                    
                    newNode.setNext(prev.getNext()); 
                    prev.getNext().setPrevious(newNode);
                    newNode.setPrevious(prev);
                    prev.setNext(newNode);
                    numElements++;
		}
	}
        public E get(int pos) {
            if (pos < 0  ||  pos >= numElements)
                throw new IndexOutOfBoundsException();
    		DNode<E> current = head;
		for (int i = 0; i < pos; i++)
                    current = current.getNext();
		return current.getElement();
	}

	public int search(E element) {
		DNode<E> current = head;
		int i = 0;
		while (current != null) {
			if (element.equals(current.getElement()))
					return i;
			i++;
			current = current.getNext();
		}
		return -1;
	}
        public E remove(int pos) {
            if (pos < 0  ||  pos >= numElements)
                throw new IndexOutOfBoundsException();
            if (pos == 0)
                return removeFirst();
            else if (pos == numElements-1) // ... ou remo��o do final
                return removeLast();
            else { 
                DNode<E> prev = head;
                    for (int i = 0; i < pos-1; i++)
                        prev = prev.getNext();
			
                E element = prev.getNext().getElement();
                prev.getNext().setPrevious(prev.getPrevious().getPrevious());
                prev.setNext(prev.getNext().getNext());

		numElements--;
                return element;
            }
	}
        public E removeLast() { 
            if (isEmpty())
                throw new UnderflowException();

            E element = tail.getElement();
            if (head == tail)
                head = tail = null;
            else {
                DNode<E> prev = head;
		while (prev.getNext() != tail)
                    prev = prev.getNext();
                    tail = prev;
                    prev.setNext(null);
		}
		numElements--;
		return element;
	}
        public E removeFirst() {
		if (isEmpty())
			throw new UnderflowException();

		E element = head.getElement();

		if (head == tail)
                    head = tail = null;
		else
		   head = head.getNext();
                   head.setPrevious(null);

                numElements--;
		return element;
	}
}
