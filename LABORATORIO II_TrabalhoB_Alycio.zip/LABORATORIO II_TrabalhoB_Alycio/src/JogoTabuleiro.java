/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unisinos
 */
public class JogoTabuleiro {
    private DoublyLinkedList<Casa> tabuleiro;

    public DoublyLinkedList<Casa> getTabuleiro() {
        return tabuleiro;
    }
    
    public JogoTabuleiro(DoublyLinkedList<Casa> tabuleiro) {
        this.tabuleiro = tabuleiro;
    }
    
    public void insereCasa(Casa casa) {
        if (tabuleiro.isEmpty()) {
            tabuleiro.insertFirst(casa);
            return;
        }
        tabuleiro.insertLast(casa);
    }

    public void setTabuleiro(DoublyLinkedList<Casa> tabuleiro) {
        this.tabuleiro = tabuleiro;
    }
    
    public void insereAcao(int posicao, String acao){
        tabuleiro.get(posicao).setAcao(acao);
    }
    
}
