/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unisinos
 */
public class Casa {
    private Jogador jogador1, jogador2, jogador3, jogador4;
    private String acao;

    public Jogador getJogador1() {
        return jogador1;
    }

    public void setJogador1(Jogador jogador1) {
        this.jogador1 = jogador1;
    }

    public Jogador getJogador2() {
        return jogador2;
    }

    public void setJogador2(Jogador jogador2) {
        this.jogador2 = jogador2;
    }

    public Jogador getJogador3() {
        return jogador3;
    }

    public void setJogador3(Jogador jogador3) {
        this.jogador3 = jogador3;
    }

    public Jogador getJogador4() {
        return jogador4;
    }

    public void setJogador4(Jogador jogador4) {
        this.jogador4 = jogador4;
    }

    public String getAcao() {
        return acao;
    }

    public void setAcao(String acao) {
        this.acao = acao;
    }

    public Casa() {
        this.acao = "nenhuma";
    }

    @Override
    public String toString() {
        return "jogador1: " + this.jogador1 + ", jogador2: " + this.jogador2 + ", jogador3: " + this.jogador3 + ", jogador4: " + this.jogador4 + ", acao: " + this.acao;
    }
    
    
    
    
}
