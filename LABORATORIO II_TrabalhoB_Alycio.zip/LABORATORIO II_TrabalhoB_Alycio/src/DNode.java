/**
 *
 * @author Unisinos
 */
public class DNode<E> {
    	protected E element;
	protected DNode<E> next;
        protected DNode<E> previous;

	public DNode(E e) {
		element = e;
                previous = null;
		next = null;
	}

	public E getElement() {
		return element; 
	}

	public DNode<E> getNext() { 
		return next;
	}

	public void setElement(E e) { 
		element = e; 
	}

	public void setNext(DNode<E> n) {
		next = n; 
	}
        
        public void setPrevious(DNode<E> n) {
            previous = n;
        }
        
        public DNode<E> getPrevious() {
            return this.previous;
        }
    
}
