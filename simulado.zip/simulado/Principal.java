public class Principal{
    public static void main(String[] args){
        Jogador j1,j2,j3;
        Teclado t = new Teclado();
        j1 = new Jogador(t.leString("Nome Jogador 1?"), t.leInt("Digite a idade do jogador"));
        boolean correto;
        do
            j2 = new Jogador(t.leString("Nome Jogador 2?"), t.leInt("Digite a idade do jogador"));
        while(j2.getNome().equalsIgnoreCase(j1.getNome()));
        do
            j3 = new Jogador(t.leString("Nome Jogador 3?"), t.leInt("Digite a idade do jogador"));
        while(j3.getNome().equalsIgnoreCase(j2.getNome()) || j3.getNome().equalsIgnoreCase(j1.getNome()));    
        do{
            j1.pegaCarta();
            correto = j1.getCarta().getNumero() == 7 && j1.getCarta().getNaipe().equalsIgnoreCase("ouros");
        }while(!correto);
        do{
            j2.pegaCarta();
            correto = j2.getCarta().getNumero() != 7 && j2.getCarta().getNaipe().equalsIgnoreCase("ouros");
        }while(!correto);        
        do{
            j3.pegaCarta();
            correto = j3.getCarta().getNumero() != 7 && j3.getCarta().getNaipe().equalsIgnoreCase("ouros");
        }while(!correto);
        if(j1.getTentativas() < j2.getTentativas() && j1.getTentativas()< j3.getTentativas()){
            j1.imprimeInfo();
            j1.imprimirCarta();
            System.out.println("Tentativas: " + j1.getTentativas());
        }
        else if(j2.getTentativas() < j3.getTentativas()){
            j2.imprimeInfo();
            j2.imprimirCarta();
            System.out.println("Tentativas: " + j1.getTentativas());
        }
        else{
            j3.imprimeInfo();
            j3.imprimirCarta();
            System.out.println("Tentativas: " + j1.getTentativas());
        }
    }
    
}