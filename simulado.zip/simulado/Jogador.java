public class Jogador{
    private String nome;
    private int idade, tentativas;
    private Carta carta;
    public Jogador(String nome, int idade){
        this.nome = nome;
        this.idade = idade;
        this.carta = null;
        this.tentativas = 0;
    }
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setIdade(int idade){
        this.idade = idade;
    }
    public String getNome(){
        return this.nome;
    }
    public int getIdade(){
        return this.idade;
    }
    public Carta getCarta(){
        return this.carta;
    }
    public int getTentativas(){
        return this.tentativas;
    }
    public void pegaCarta(){
        int naipeRandom = (int)(Math.random()*4 + 1);
        String naipe ="";
        switch(naipeRandom){
            case 1:
                naipe = "copas";
                break;
            case 2: 
                naipe = "ouros";
                break;
            case 3:
                naipe = "paus";
                break;
            case 4:
                naipe = "espadas";
                break;            
        }
        carta = new Carta((int)(Math.random()*12 +1) , naipe);
        this.tentativas++;
    }
    public void imprimirCarta(){
        if(carta != null){
            carta.imprimeInfo();
        }
    }
    public void imprimeInfo(){
        System.out.println("Nome: " + nome + "\nIdade: " + idade);
    }
}